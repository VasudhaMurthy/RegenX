package com.example.regenx.screens.collectors

class CollectorMapScreen {
}