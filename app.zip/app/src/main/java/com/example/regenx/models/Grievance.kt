package com.example.regenx.models
data class Grievance(
    val id: String = "",
    val type: String = "",
    val userId: String = "",
    val description: String = "",
    val status: String = ""
)
