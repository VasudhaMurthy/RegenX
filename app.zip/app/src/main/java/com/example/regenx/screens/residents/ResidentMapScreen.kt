package com.example.regenx.screens.residents

class ResidentMapScreen {
}