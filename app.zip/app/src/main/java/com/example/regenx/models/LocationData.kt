package com.example.regenx.models

data class LocationData(
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long
)
